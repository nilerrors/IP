//
// Created by nilerrors on 13/12/2023.
//

#include <iostream>
#include "World.h"

World::World(const string &name) : name(name) {}

World::~World() {
//    int len = levels.size();
//    for (int i =0; i < len; i++) {
//        delete levels[i];
//        levels[i] = nullptr;
//    }
    for (auto &level : levels) {
        delete level;
        level = nullptr;
    }
    levels.clear();
}

void World::addLevel(Level *level) {
    levels.push_back(level);
}
