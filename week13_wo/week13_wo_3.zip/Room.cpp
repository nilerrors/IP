//
// Created by nilerrors on 13/12/2023.
//

#include "Room.h"

Room::Room(const string &description) : description(description) {}

string Room::toString() const {
    return "This is a room called '" + description + "'";
}

Room::~Room() {

}
