//
// Created by nilerrors on 13/12/2023.
//

#ifndef WEEK13_WO_ROOM_H
#define WEEK13_WO_ROOM_H

#include <string>

using namespace std;

class Room {
    string description;
public:
    explicit Room(const string &description);

    virtual ~Room();

    virtual string toString() const;
};


#endif //WEEK13_WO_ROOM_H
