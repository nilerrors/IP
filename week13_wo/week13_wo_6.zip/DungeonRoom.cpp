//
// Created by nilerrors on 13/12/2023.
//

#include "DungeonRoom.h"

DungeonRoom::DungeonRoom(const string &description) : Room(description) {}

DungeonRoom::~DungeonRoom() {

}
