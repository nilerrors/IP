//
// Created by nilerrors on 14/12/2023.
//

#include "MonsterCharacter.h"

MonsterCharacter::MonsterCharacter(const string &name, int attackPower, int defensePower, int healthScore) : Character(
        name, attackPower, defensePower, healthScore) {}

MonsterCharacter::~MonsterCharacter() {

}
