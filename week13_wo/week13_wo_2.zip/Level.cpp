//
// Created by MCS 7390 LATITUDE on 13/12/2023.
//

#include "Level.h"

Level::Level(const string &name) : name(name) {}
