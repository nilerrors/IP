//
// Created by  on 13/12/2023.
//

#ifndef WEEK13_WO_LEVEL_H
#define WEEK13_WO_LEVEL_H


#include <string>

using namespace std;

class Level {
string name;
public:
    explicit Level(const string &name);
};


#endif //WEEK13_WO_LEVEL_H
