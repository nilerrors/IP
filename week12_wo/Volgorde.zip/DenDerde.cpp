//
// Created by nilerrors on 07/12/2023.
//

#include "DenDerde.h"
#include <iostream>

using namespace std;

DenDerde::DenDerde() {
    cout << "3, ";
}

DenDerde::~DenDerde() {
    cout << "5, ";
}
