//
// Created by nilerrors on 07/12/2023.
//

#include "DenTweede.h"
#include <iostream>

using namespace std;

DenTweede::DenTweede() {
    cout << "1, ";
}

DenTweede::~DenTweede() {
    cout << "8.";
}
