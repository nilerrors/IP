//
// Created by nilerrors on 07/12/2023.
//

#ifndef WEEK12_WO_DENDERDE_H
#define WEEK12_WO_DENDERDE_H


class DenDerde {
public:
    DenDerde();

    virtual ~DenDerde();
};


#endif //WEEK12_WO_DENDERDE_H
