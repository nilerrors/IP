//
// Created by MCS 7390 LATITUDE on 07/12/2023.
//

#ifndef WEEK12_WO_ENDEVIERDE_H
#define WEEK12_WO_ENDEVIERDE_H


class EnDeVierde {
public:
    virtual ~EnDeVierde();

    EnDeVierde();
};


#endif //WEEK12_WO_ENDEVIERDE_H
