//
// Created by MCS 7390 LATITUDE on 07/12/2023.
//

#include "EnDeVierde.h"
#include <iostream>

using namespace std;

EnDeVierde::EnDeVierde() {
    cout << "2, ";
}

EnDeVierde::~EnDeVierde() {
    cout << "7, ";
}


