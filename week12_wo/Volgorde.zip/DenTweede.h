//
// Created by nilerrors on 07/12/2023.
//

#ifndef WEEK12_WO_DENTWEEDE_H
#define WEEK12_WO_DENTWEEDE_H


class DenTweede {
public:
    DenTweede();

    virtual ~DenTweede();
};


#endif //WEEK12_WO_DENTWEEDE_H
