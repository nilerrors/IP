#include "VeeltermFunctie.h"

const string& VeeltermFunctie::getNaam() const {
  return VeeltermFunctie::naam;
}

int VeeltermFunctie::getGraad() const {
  if (VeeltermFunctie::coefficienten.empty())
    return 0;
  return VeeltermFunctie::coefficienten.size() - 1;
}

void VeeltermFunctie::setNaam(const string& naam) {
  VeeltermFunctie::naam = naam;
}

void VeeltermFunctie::setCoefficienten(const vector<int>& coefficienten) {
  VeeltermFunctie::coefficienten = coefficienten;
}

const string& VeeltermFunctie::toString() const {
  static string result;
  result = VeeltermFunctie::naam + "(x) = ";
  for (int i = VeeltermFunctie::coefficienten.size() - 1;
       i < VeeltermFunctie::coefficienten.size(); i--) {
    if (i < VeeltermFunctie::coefficienten.size() - 1 &&
        VeeltermFunctie::coefficienten[i] > 0)
      result += " + ";
    if (i == 0) {
      result += to_string(VeeltermFunctie::coefficienten[i]);
    } else if (i == 1) {
      result += to_string(VeeltermFunctie::coefficienten[i]) + " x";
    } else {
      result +=
          to_string(VeeltermFunctie::coefficienten[i]) + " x^" + to_string(i);
    }
  }
  return result;
}

double VeeltermFunctie::berekenFunctiewaarde(double x) const {
  double result = 0;
  for (int i = 0; i < VeeltermFunctie::coefficienten.size(); i++) {
    result += VeeltermFunctie::coefficienten[i] * pow(x, i);
  }
  return result;
}

VeeltermFunctie VeeltermFunctie::berekenAfgeleide() const {
  VeeltermFunctie result;

  result.setNaam(VeeltermFunctie::naam + "'");
  vector<int> coefficienten;

  for (int i = 1; i < VeeltermFunctie::coefficienten.size(); i++) {
    coefficienten.push_back(VeeltermFunctie::coefficienten[i] * i);
  }

  result.setCoefficienten(coefficienten);

  return result;
}
