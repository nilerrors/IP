#include "RationaleFunctie.h"
#include <iostream>

const string& RationaleFunctie::getNaam() const {
  return naam;
}

void RationaleFunctie::setNaam(const string& naam) {
  RationaleFunctie::naam = naam;
}

void RationaleFunctie::setTeller(const VeeltermFunctie& teller) {
  RationaleFunctie::teller = teller;
}

void RationaleFunctie::setNoemer(const VeeltermFunctie& noemer) {
  if (noemer.getGraad() == 0 && noemer.berekenFunctiewaarde(1) == 0) {
    cout << "Ongeldige noemer" << endl;
    return;
  }
  RationaleFunctie::noemer = noemer;
}

string RationaleFunctie::toString() const {
  string result;
  result = naam + "(x) = (" + teller.termenToString() + ") / (" +
           noemer.termenToString() + ")";

  return result;
}

double RationaleFunctie::berekenFunctiewaarde(double x) const {
  if (noemer.berekenFunctiewaarde(x) == 0) {
    cout << "Deze waarde ligt buiten het domein van de functie" << endl;
    return 0;
  }
  return teller.berekenFunctiewaarde(x) / noemer.berekenFunctiewaarde(x);
}
