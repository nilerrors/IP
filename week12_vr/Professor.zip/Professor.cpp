//
// Created by nilerrors on 10/12/2023.
//

#include "Professor.h"

Professor::Professor(const string &voornaam, const string &achternaam) : voornaam(voornaam), achternaam(achternaam) {}

const string &Professor::getVoornaam() const {
    return voornaam;
}

const string &Professor::getAchternaam() const {
    return achternaam;
}

string Professor::toString() const {
    return "Professor " + voornaam + " " + achternaam;
}

void Professor::geeft(Cursus *cursus) {
    curssusen.push_back(cursus);
}
