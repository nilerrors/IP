//
// Created by nilerrors on 10/12/2023.
//

#ifndef WEEK12_VR_PROFESSOR_H
#define WEEK12_VR_PROFESSOR_H

#include <string>
#include <vector>
#include "Cursus.h"
#include "Persoon.h"

using namespace std;


class Professor : Persoon {
    vector<Cursus *> curssusen;

public:
    Professor(const string &voornaam, const string &achternaam);

    const string &getVoornaam() const;

    const string &getAchternaam() const;

    string toString() const;

    void geeft(Cursus *cursus);
};


#endif //WEEK12_VR_PROFESSOR_H
