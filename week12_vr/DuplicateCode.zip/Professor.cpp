//
// Created by nilerrors on 10/12/2023.
//

#include "Professor.h"

Professor::Professor(const string &voornaam, const string &achternaam) : Persoon(voornaam, achternaam) {}

const string &Professor::getVoornaam() const {
    return Persoon::getVoornaam();
}

const string &Professor::getAchternaam() const {
    return Persoon::getAchternaam();
}

string Professor::toString() const {
    return "Professor " + Persoon::toString();
}

void Professor::geeft(Cursus *cursus) {
    curssusen.push_back(cursus);
}
