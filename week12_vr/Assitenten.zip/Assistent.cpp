//
// Created by nilerrors on 10/12/2023.
//

#include "Assistent.h"

Assistent::Assistent(const string &voornaam, const string &achternaam) : Lesgever(voornaam, achternaam) {}

Professor *Assistent::getBegeleider() const {
    return begeleider;
}

void Assistent::setBegeleider(Professor *begeleider) {
    Assistent::begeleider = begeleider;
}
