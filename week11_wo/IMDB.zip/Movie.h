#ifndef MOVIE_MOVIE_H_
#define MOVIE_MOVIE_H_

#include <string>
#include <vector>

using namespace std;

class Movie {
  // year, director, title, genre, actors en rating
  int year;
  string director;
  string title;
  string genre;
  vector<string> actors;
  double rating;

 public:
  Movie(int year,
        string director,
        string title,
        string genre,
        const vector<string>& actors,
        double rating);

  int getYear() const { return year; }
  string getDirector() const { return director; }
  string getTitle() const { return title; }
  string getGenre() const { return genre; }
  const vector<string> getActors() const { return actors; }
  double getRating() const { return rating; }

  void setYear(int year) { Movie::year = year; }
  void setDirector(const string director) { Movie::director = director; }
  void setTitle(const string title) { Movie::title = title; }
  void setGenre(const string genre) { Movie::genre = genre; }
  void setActors(const vector<string>& actors) { Movie::actors = actors; }
  void setRating(double rating) { Movie::rating = rating; }

  // Returns a string representation of the movie, e.g. "The Matrix (1999)"
  string toString() const;

  // Adds an actor to the list of actors
  void starring(string name);
};

#endif /* MOVIE_MOVIE_H_ */
