#ifndef MOVIE_IMDB_H_
#define MOVIE_IMDB_H_

#include <string>
#include <vector>
#include "Movie.h"

class IMDB {
  vector<Movie> movies;

 public:
  IMDB() {}
  IMDB(const vector<Movie>& movies) : movies(movies) {}

  void addMovie(const Movie& movie);
  Movie getBest();
  vector<Movie> getSimilar(const Movie& movie);

  string toString() const;
};

#endif /* MOVIE_IMDB_H_ */
