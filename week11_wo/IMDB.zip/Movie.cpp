#include "Movie.h"

Movie::Movie(int year,
             string director,
             string title,
             string genre,
             const vector<string> &actors,
             double rating) {
  Movie::year = year;
  Movie::director = director;
  Movie::title = title;
  Movie::genre = genre;
  Movie::actors = actors;
  Movie::rating = rating;
}

string Movie::toString() const {
  return Movie::title + " (" + to_string(Movie::year) + ")";
}

void Movie::starring(string name) {
  Movie::actors.push_back(name);
}
