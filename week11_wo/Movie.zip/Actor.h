#ifndef MOVIE_ACTOR_H_
#define MOVIE_ACTOR_H_

#include "Person.h"

typedef Person Actor;

#endif /* MOVIE_ACTOR_H_ */
