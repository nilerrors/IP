#ifndef MOVIE_DIRECTOR_H_
#define MOVIE_DIRECTOR_H_

#include "Person.h"

typedef Person Director;

#endif /* MOVIE_DIRECTOR_H_ */
